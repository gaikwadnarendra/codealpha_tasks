
import chainlit as cl
import redis
import json
import requests
from dotenv import load_dotenv
import os
from typing import Optional, List,Dict
import time
import jwt
from jwt.exceptions import InvalidTokenError
from chainlit.types import ThreadDict
from chainlit.data.sql_alchemy import SQLAlchemyDataLayer
from chainlit.input_widget import Select, Switch, Slider
from llama_api import llama_completion
from literalai import LiteralClient
import sqlite3
import asyncpg
from google.auth.transport.requests import Request
from google.oauth2 import id_token

def get_chat_response():
        
    # Load environment variables
    load_dotenv()
    JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET", "default_secret")
    JWT_ALGORITHM = "HS256"
    SESSION_EXPIRY = 3600 

    # User database (replace with proper database in production)
    user_db = {
        "admin": {"password": "admin", "role": "admin"},
        "user1": {"password": "user1pass", "role": "user"},
        "user2": {"password": "user2pass", "role": "user"},
    }

    # Redis setup
    redis_client = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)



    # JWT Utilities
    def create_jwt(username: str) -> str:
        return jwt.encode(
            {
                "username": username,
                "exp": time.time() + SESSION_EXPIRY
            },
            JWT_SECRET,
            algorithm=JWT_ALGORITHM
        )

    def validate_jwt(token: str) -> bool:
        try:
            jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            return True
        except InvalidTokenError:
            return False

    # # Authentication 
    @cl.password_auth_callback
    async def auth_callback(username: str, password: str) -> Optional[cl.User]:
        if user_db.get(username) and user_db[username]["password"] == password:
            return cl.User(
                identifier=username,
                metadata={"role": user_db[username]["role"]}
            )
        return None

    @cl.oauth_callback
    def oauth_callback(
        provider_id: str,
        token: str,
        raw_user_data: Dict[str, str],
        default_user: cl.User,
    ) -> Optional[cl.User]:
        # You can add additional checks here if needed
        return default_user  # Allow all users to authenticate

    @cl.set_starters
    async def set_starters():
        samples = []
        with open(os.path.join('public', 'sample.json'), 'r') as f:
            samples = json.loads(f.read())
        
        starter_prompts = []
        for sam in samples:
            starter_prompts.append(
                    cl.Starter(
                    label=sam['label'],
                    message=sam['message'],
                    icon=sam['icon'],
                ))
        
        return starter_prompts

    # Chat History Management
    def save_chat_history(username: str, session_id: str, role: str, content: str):
        if not redis_client:
            return
        
        try:
            key = f"chat:{username}:{session_id}"
            redis_client.rpush(key, json.dumps({
                "role": role,
                "content": content,
                "timestamp": time.time()
            }))
            redis_client.expire(key, 86400)  # Expire after 24h
            
            # Track user sessions
            # redis_client.sadd(f"sessions:{username}", session_id)
        except redis.RedisError as e:
            print(f"Redis error: {e}")

    def get_chat_history(username: str, session_id: str) -> List[Dict]:
        if not redis_client:
            return []
        
        try:
            key = f"chat:{username}:{session_id}"
            return [json.loads(msg) for msg in redis_client.lrange(key, 0, -1)]
        except redis.RedisError as e:
            print(f"Redis error: {e}")
            return []



    @cl.data_layer
    def get_data_layer():
        # return SQLAlchemyDataLayer(conninfo="oracle+oracledb://KITTY:password@192.168.0.252:1521/orcl")
        return SQLAlchemyDataLayer(conninfo="postgresql+asyncpg://chatbot_user:password@192.168.0.88:5432/chatbotdb")

    # Session Management
    def get_user_sessions(username: str) -> List[str]:
        if not redis_client:
            return []
        return redis_client.smembers(f"sessions:{username}") or []

    # # Chainlit Handlers
    @cl.on_chat_start
    async def start_chat():
        cl.user_session.set("chat_history", [])

        user = cl.user_session.get("user")
        if not user:
            await cl.Message(content="Authentication required").send()
            return
        
        # Generate session ID and JWT
        session_id = cl.user_session.get("id") or str(time.time_ns())
        cl.user_session.set("id", session_id)
        token = create_jwt(user.identifier)
        cl.user_session.set("token", token)
        
        # Show resume options
        sessions = get_user_sessions(user.identifier)
        if sessions:
            actions = [
                cl.Action(
                    name=f"resume_{sid}",
                    payload={"session_id": sid},  # Add a valid payload
                    label=f"Session {sid[-6:]}"
                ) for sid in sessions if sid != session_id
            ]
            # await cl.Message(content="Active sessions:", actions=actions).send()

    @cl.on_message
    async def on_message(message: cl.Message):
        # Note: by default, the list of messages is saved and the entire user session is saved in the thread metadata
        chat_history = cl.user_session.get("chat_history")

        # api_key = os.environ["MISTRAL_API_KEY"]
        # model = "ministral-8b-latest"

        # client = Mistral(api_key=api_key)

        chat_history.append({"role": "user", "content": message.content})

        # chat_response = client.chat.complete(model=model, messages=chat_history)
        response = llama_completion(chat_history)
        # response_content = chat_response.choices[0].message.content

        # Prepare message to stream token responses
        msg = cl.Message(content="")
        await msg.send()
        try:
            # Stream the response tokens in real-time
            for token in response:
                await msg.stream_token(token)
            # Optionally, send a message that the streaming is complete
            # await cl.Message(content="All tokens streamed successfully.").send()
            await msg.update()
        except Exception as e:
            await cl.Message(content=f"Error streaming response: {e}").send()

        chat_history.append({"role": "assistant", "content": response})

        # await cl.Message(content=response).send()

    @cl.on_chat_resume
    async def on_chat_resume(thread):
        pass

get_chat_response()







