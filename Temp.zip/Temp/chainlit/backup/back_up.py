import chainlit as cl
import redis
import json
import requests

# Redis setup
redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

# Chat service endpoint
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"
# CHAT_SERVICE_URL = "ws://192.168.0.243:9090/v1/chat/completions/ws"
# Function to call the LLaMA model API
def llama_completion(prompt, history):
    try:
        # Create the conversation context by including previous user instructions
        messages = [{"role": "system", "content": "You are a helpful assistant."}]
        
        # Add all prior conversation history to the messages
        for msg in history:
            messages.append({"role": msg['role'], "content": msg['content']})

        # Add the current user message
        messages.append({"role": "user", "content": prompt})

        # Prepare the request payload
        data = {"messages": messages}

        headers = {"Content-Type": "application/json"}

        # Send the request to the chat service (LLaMA model API)
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data), stream=True)
        response_json = response.json()

        # Extract assistant's reply
        assistant_reply = response_json['choices'][0]['message']['content']

        # If the assistant response is not meaningful, return the last valid response
        if "I don't understand" in assistant_reply or not assistant_reply.strip():
            assistant_reply = "I'm following the previous instruction. Please clarify your new instruction."
        
        # Add the assistant's reply to the history
        history.append({"role": "assistant", "content": assistant_reply})
        
        return assistant_reply
    
    except requests.RequestException:
        return "Service Unavailable"


# Store the conversation in Redis
def store_conversation_history(thread_id, history):
    redis_client.set(thread_id, json.dumps(history))
    # conversation history expiry
    #redis_client.expire(thread_id, 30)  # 10 seconds TTL

    # redis_client.expire(thread_id, 3600)  # 1-hour TTL
    # redis_client.expire(thread_id,, 86400)  # Expire after 24 hours
    # redis_client.ltrim(thread_id, -100, -1)  # Keep only the last 100 messages


# Retrieve the conversation history from Redis
def retrieve_conversation_history(thread_id):
    history = redis_client.get(thread_id)
    if history:
        return json.loads(history)
    return []

@cl.on_chat_start
async def on_chat_start():
    cl.user_session.set("chat_history", [])

async def start():
        with cl.Sidebar():
            cl.Markdown("settings")
            theme = cl.Select(
                options=["Light", "Dark"],
                value="Light",
                label="Choose Theme",
            )
            toggle = cl.Switch(value=False,
                               label="Enable Feature!")
            
            if toggle:
                cl.Text("Feature enabled!")
                
        '''elements = [
            cl.Text(content="Initial text")
        ]
        await cl.ElementSidebar.set_elements(elements)
        await cl.ElementSidebar.set_title("My Sidebar")'''

'''@cl.on_message
async def main(message:str):
    # Displaying response in the main chat
    await cl.Message(content=f"You said: {message}").send()'''
@cl.on_message
async def on_message(message: cl.Message):

    # get the thread id from the message
    thread_id = message.thread_id
    #thread_id = thread.id

    # Retrieve chat history from Redis
    conversation_history = retrieve_conversation_history(thread_id)

    # Append user message to conversation history
    conversation_history.append({"role": "user", "content": message.content})

    # Display chat history in the sidebar
    '''with cl.sidebar(): 
        cl.html("<h3>This is Your Chat History in this Chat</h3>")
        for msg in conversation_history:
            role = "User" if msg["role"] == "user" else "Assistant"
            cl.html(f"<p><b>{role}:</b> {msg['content']}</p>")'''

    # check if the user is requesting the history
    if message.content.lower() == "show history":
        if conversation_history:
            history_message = "\n".join([f"{'User' if msg['role'] == 'user' else 'Assistant'}: {msg['content']}" for msg in conversation_history])
            await cl.Message(content=f"Chat History:\n{history_message}").send()
        else:
            await cl.Message(content="No chat history available yet. How can I assist you today?").send()
        return  # Skip the normal assistant reply if history is being shown
    
    # Get the final response after the stream finishes
    #response_content = "".join([token for token in stream])  # Accumulate response tokens

    # Get response from LLaMA API
    response_content = llama_completion(message.content, conversation_history)
    
     # Send streaming response
    msg = cl.Message(content="")  # Empty message object for streaming
    await msg.send() 

    response = ""
    for token in response_content:
        response += token
        await msg.stream_token(token)
    

    # Append assistant's response to the conversation history
    conversation_history.append({"role": "assistant", "content": response})

    # Store updated chat history in Redis
    store_conversation_history(thread_id, conversation_history)

    # Send response to user
    await cl.Message(content=response).send()


    '''# Optionally, display history as needed (no explicit sidebar or CSS required)
    if len(conversation_history) > 5:  # Just an example condition to display history
        await cl.Message(content="Would you like to see more history?").send()'''

    #await cl.ElementSidebar.set_elements("History")
    #await cl.ElementSidebar.set_elements([cl.Text(content="History stored!")])
    # await cl.ElementSidebar.set_elements([cl.Text(content="History")])
    #await cl.ElementSidebar.set_title("My Sidebar")

    #with cl.Sidebar():  # Ensure this is correct
    await cl.ElementSidebar.set_elements([cl.Text(content="History")])


@cl.on_chat_resume
async def on_chat_resume(thread):
   # get thread ID and retrive the conversation history
    thread_id = thread_id
    conversation_history = retrieve_conversation_history(thread_id)

    if conversation_history:
        history_message = "\n".join([f"{'User' if msg['role'] == 'user' else 'Assistant'}: {msg['content']}" for msg in conversation_history])
        await cl.Message(content=f"Chat History:\n{history_message}").send()
    else:
        await cl.Message(content="No chat history available yet. How can I assist you today?").send()


