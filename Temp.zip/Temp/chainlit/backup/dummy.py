from typing import Optional,Dict
import chainlit as cl
from dotenv import load_dotenv
import os
import redis
import requests
import json
import time
import jwt 
from chainlit.input_widget import Select, Switch, Slider
from chainlit.types import ThreadDict
import time
import asyncio
import io
import aiohttp
import base64
# from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
# Load environment variables from .env file
load_dotenv() 

transcription_result = []
# Define chat service URL
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"

# Function to get responses from LLaMA API
def llama_completion(messages):
    try:
        # start_time = time.time()
        data = {"messages": messages}
        headers = {"Content-Type": "application/json"}
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Ensure we raise an error for HTTP issues
        response_json = response.json()
        # end_time = time.time()
        # print("Start time:", time.ctime(start_time))
        # print("End time:", time.ctime(end_time))
        # elapsed_time = end_time - start_time
        # print("Elapsed time:", elapsed_time, "seconds")
        return response_json['choices'][0]['message']['content']
    except requests.RequestException as e:
        print(f"Error communicating with LLaMA API: {e}")
        return "Service Unavailable"
    
# #Profile versions
@cl.set_chat_profiles
async def chat_profile():
    return [
        cl.ChatProfile(
            name="Chatbot-3.5",
            markdown_description="Credentek AI Chatboat",
            icon="/public/images/crd1.png",
        ),
# #         cl.ChatProfile(
#             name="CHAINLIT-4",
#             markdown_description="The Chainlit model **CHAINLIT-4**.",
#             icon="https://pbs.twimg.com/profile_images/1657041791613370369/sm9jmDm3_400x400.jpg",
#         ),
#         cl.ChatProfile(
#             name="CHAINLIT-5",
#             markdown_description="The Chainlit model **CHAINLIT-5**.",
#             icon="https://pbs.twimg.com/profile_images/1657041791613370369/sm9jmDm3_400x400.jpg",
#         ),
    ]


# Set the JWT secret from environment variables
JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET")
JWT_ALGORITHM = "HS256"  # You can choose an appropriate algorithm
if not JWT_SECRET:
    raise ValueError("JWT_SECRET is not set in the environment variables.")
else:
    print("JWT_SECRET loaded successfully.")


@cl.set_starters
async def set_starters():
    return [
        cl.Starter(
            label="Write a python code?",
            message="write a python code?",
            icon="/public/images/python.jpeg",
            ),

        cl.Starter(
            label="About chainlit",
            message="Explain superconductors like I'm five years old.",
            icon="/public/images/chainlit.png",
            ),
        cl.Starter(
            label="Help me write",
            message="Help me write a blogs?",
            icon="/public/images/writting.png",
            ),
        cl.Starter(
            label="summerize text",
            message="Summerize a reserch paper",
            icon="/public/images/summerize.jpeg",
            )
        ]

user_db = {
    "admin": {"password": "admin", "role": "admin"},
    "user1": {"password": "pass", "role": "user"},
}  
def validate_jwt(token):
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return True  # Token is valid
    except jwt.ExpiredSignatureError:
        return False  # Token has expired
    except jwt.InvalidTokenError:
        return False  # Invalid token
    
# Google OAuth 2.0 verification and user data retrieval
# def verify_google_token(google_token: str) -> Optional[dict]:
#     try:
#         # Verify the Google token
#         request = google_requests.Request()
#         id_info = id_token.verify_oauth2_token(google_token, request, audience=GOOGLE_CLIENT_ID)
#         return id_info
#     except ValueError as e:
#         print(f"Invalid Google token: {e}")
#         return None

# # Store user data in Redis
# def store_user_data(username: str, email: str, name: str, role: str = "user"):
#     if not r.exists(f'users:{username}'):
#         # Store user information in Redis
#         r.hset(f'users:{username}', 'email', email)
#         r.hset(f'users:{username}', 'name', name)
#         r.hset(f'users:{username}', 'role', role)
#         # Generate a password hash (can be a dummy password, as Google login uses token)
#         r.hset(f'users:{username}', 'password', generate_password_hash('dummy-password'))

# Callback function to handle Google login and JWT generation
# @cl.password_auth_callback
# def auth_callback(username: str, password: str, google_token: Optional[str] = None) -> Optional[cl.User]:
#     # If a Google token is provided, validate it
#     if google_token:
#         user_info = verify_google_token(google_token)
#         if user_info:
#             username = user_info['email']
#             email = user_info['email']
#             name = user_info.get('name', 'Unknown')
            
#             store_user_data(username, email, name)
            
#             token = jwt.encode({"username": username}, JWT_SECRET, algorithm=JWT_ALGORITHM)
            
#             return cl.User(
#                 identifier=username,
#                 metadata={"role": r.hget(f'users:{username}', 'role'), "provider": "google", "token": token},
#             )
    
#     return None

# Implementing password authentication callback
@cl.password_auth_callback
def auth_callback(username: str, password: str) -> Optional[cl.User]:
    # Check if the user exists in the user_db and if the password is correct
    if username in user_db and user_db[username]["password"] == password:
        # Generate a JWT token upon successful authentication
        token = jwt.encode({"username": username}, JWT_SECRET, algorithm=JWT_ALGORITHM)
        return cl.User(
            identifier=username,
            metadata={"role": user_db[username]["role"], "provider": "credentials", "token": token},
        )
    else:
        return None
    
@cl.oauth_callback
def oauth_callback(
    provider_id: str,
    token: str,
    raw_user_data: Dict[str, str],
    default_user: cl.User,) -> Optional[cl.User]:
    return default_user

# Connect to Redis
try:
    redis_client = redis.StrictRedis(host="localhost", port=6379, db=0, decode_responses=True)
    redis_client.ping() 
except redis.ConnectionError:
    print("Error: Unable to connect to Redis")
    redis_client = None 
def save_chat_history(session_id, role, content):
    if redis_client:
        key = f"chat:{session_id}"
        redis_client.rpush(key, json.dumps({"role": role, "content": content}))

# Retrieve chat history from Redis
def get_chat_history(session_id):
    if redis_client:
        key = f"chat:{session_id}"
        history = redis_client.lrange(key, 0, -1)
        return [json.loads(msg) for msg in history] if history else []
    return []


@cl.on_chat_start
async def main():
    elements = [
        cl.Text(content="Click to View User History", name="history_button", metadata={"action": "show_history"})
    ]
    
    # Set sidebar elements and title
    await cl.ElementSidebar.set_elements(elements)
    await cl.ElementSidebar.set_title("Sidebar Menu")

# @cl.on_settings_update
# async def setup_agent(settings):
#     print("on_settings_update", settings)

 
@cl.on_message
async def on_message(message: cl.Message):
    session_id = cl.user_session.get("id")
    # Regular chat message processing
    chat_history = get_chat_history(session_id)
    formatted_history = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history] if chat_history else []
        
    # Append the user's current message to the history
    formatted_history.append({"role": "user", "content": message.content})

    # Save the user's message to Redis chat history
    save_chat_history(session_id, "user", message.content)

    # Get the assistant's response from LLaMA API based on the conversation history
    response = llama_completion(formatted_history)

    # Save the assistant's response to Redis chat history
    save_chat_history(session_id, "assistant", response)

    # Prepare message to stream token responses
    msg = cl.Message(content="")
    await msg.send()
    try:
        # Stream the response tokens in real-time
        for token in response:
            await msg.stream_token(token)
        # Optionally, send a message that the streaming is complete
        # await cl.Message(content="All tokens streamed successfully.").send()
    except Exception as e:
        await cl.Message(content=f"Error streaming response: {e}").send()

    # Retrieve the updated chat history from Redis (with the most recent messages)
    updated_history = get_chat_history(session_id)

    # Format chat history messages
    history_elements = [
        cl.Text(
            content=f"🗨️ {msg['role'].capitalize()}: {msg['content']}", 
            name=f"message_{index}"
        )
        for index, msg in enumerate(updated_history[-10:])  # Last 10 messages
    ]

    # Add a title with a horizontal line for better styling
    # await cl.ElementSidebar.set_elements([
    #     cl.Text(content="📜 **Chat History**", name="sidebar_title"),
    #     cl.Text(content="---"),  # Simulating a divider
    # ] + history_elements)

    # # Optionally, display a brief "History updated!" message in the sidebar
    await cl.ElementSidebar.set_elements([cl.Text(content="History updated!")])
    await cl.ElementSidebar.set_title("Chat History")
    # await cl.sleep(1)  # Briefly display the "History updated!" message
    await cl.ElementSidebar.set_elements(history_elements)  # Ensure history stays in sidebar

    # Store session ID in Redis to track active chat sessions (optional)
    if redis_client:
        redis_client.sadd("chat_sessions", session_id)
            

@cl.on_chat_resume
async def chat_resume():
    # Retrieve the session ID from the user's session
    session_id = cl.user_session.get("id")
    print(session_id)
    if not session_id:
        # If session ID is missing, send an error message
        await cl.Message(content="Error: Unable to resume chat. Session ID is missing!").send()
        return

    # Fetch chat history for this session from Redis (or other storage mechanism)
    chat_history = redis_client.get(session_id)
    
    if chat_history:
        # Assuming chat history is stored as a list of dictionaries in JSON format
        history_content = "Resuming chat...\n"
        # Parse the chat history from JSON or other serialized format
        chat_history = json.loads(chat_history)
        
        # Format the last few messages for display
        for msg in chat_history[-5:]:  # Display the last 5 messages (or adjust as needed)
            history_content += f"{msg['role'].capitalize()}: {msg['content']}\n"
        
        await cl.Message(content=history_content).send()
    else:
        # If there's no history, let the user know and continue the conversation
        await cl.Message(content="No previous history found. How can I assist you today?").send()

    # Optionally, send a general greeting or confirmation message
    await cl.Message(content="Welcome back! How can I assist you further?").send()