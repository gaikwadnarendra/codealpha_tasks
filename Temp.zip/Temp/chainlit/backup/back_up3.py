import chainlit as cl
import redis
import json
import requests
from dotenv import load_dotenv
import os
from typing import Optional, List,Dict
import time
import jwt
from jwt.exceptions import InvalidTokenError
from chainlit.types import ThreadDict
from langchain.memory import ConversationBufferMemory
from chainlit.data.sql_alchemy import SQLAlchemyDataLayer

from chainlit.input_widget import Select, Switch, Slider
import oracledb
from llama_api import llama_completion

from literalai import LiteralClient
import sqlite3
import asyncpg
# Load environment variables
load_dotenv()
JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET", "default_secret")
JWT_ALGORITHM = "HS256"
SESSION_EXPIRY = 3600  # 1 hour

# User database (replace with proper database in production)
user_db = {
    "admin": {"password": "admin", "role": "admin"},
    "user1": {"password": "user1pass", "role": "user"},
}


# Redis setup
redis_client = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)



# JWT Utilities
def create_jwt(username: str) -> str:
    return jwt.encode(
        {
            "username": username,
            "exp": time.time() + SESSION_EXPIRY
        },
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

def validate_jwt(token: str) -> bool:
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return True
    except InvalidTokenError:
        return False





# Authentication ##########################################################
@cl.password_auth_callback
async def auth_callback(username: str, password: str) -> Optional[cl.User]:
    if user_db.get(username) and user_db[username]["password"] == password:
        return cl.User(
            identifier=username,
            metadata={"role": user_db[username]["role"]}
        )
    return None

@cl.oauth_callback
def oauth_callback(
    provider_id: str,
    token: str,
    raw_user_data: Dict[str, str],
    default_user: cl.User,
) -> Optional[cl.User]:
    # You can add additional checks here if needed
    return default_user  # Allow all users to authenticate

######################################################################################





#############################################################################################################


# @cl.set_chat_profiles
# async def chat_profile(current_user: cl.User):
#     return [cl.ChatProfile (
#         name="My Chat Profile",
#         icon="public/favicon.png",
#         markdown_description="Credentek Chatbot Ai",
#         )]



@cl.set_starters
async def set_starters():
    samples = []
    with open(os.path.join('public', 'sample.json'), 'r') as f:
        samples = json.loads(f.read())
    
    starter_prompts = []
    for sam in samples:
        starter_prompts.append(
                cl.Starter(
                label=sam['label'],
                message=sam['message'],
                icon=sam['icon'],
            ))
    
    return starter_prompts




# Chat History Management
def save_chat_history(username: str, session_id: str, role: str, content: str):
    if not redis_client:
        return
    
    try:
        key = f"chat:{username}:{session_id}"
        redis_client.rpush(key, json.dumps({
            "role": role,
            "content": content,
            "timestamp": time.time()
        }))
        redis_client.expire(key, 86400)  # Expire after 24h
        
        # Track user sessions
        # redis_client.sadd(f"sessions:{username}", session_id)
    except redis.RedisError as e:
        print(f"Redis error: {e}")

def get_chat_history(username: str, session_id: str) -> List[Dict]:
    if not redis_client:
        return []
    
    try:
        key = f"chat:{username}:{session_id}"
        return [json.loads(msg) for msg in redis_client.lrange(key, 0, -1)]
    except redis.RedisError as e:
        print(f"Redis error: {e}")
        return []



@cl.data_layer
def get_data_layer():
    # return SQLAlchemyDataLayer(conninfo="oracle+oracledb://KITTY:password@192.168.0.252:1521/orcl")
    return SQLAlchemyDataLayer(conninfo="postgresql+asyncpg://myuser:1234@192.168.0.74:5432/mychainlitdb")

# @cl.on_chat_start
# async def start():
#     settings = await cl.ChatSettings(
#         [
#             Select(
#                 id="Model",
#                 label="OpenAI - Model",
#                 values=["gpt-3.5-turbo", "gpt-3.5-turbo-16k", "gpt-4", "gpt-4-32k"],
#                 initial_index=0,
#             ),
#             Switch(id="Streaming", label="OpenAI - Stream Tokens", initial=True),
#             Slider(
#                 id="Temperature",
#                 label="OpenAI - Temperature",
#                 initial=1,
#                 min=0,
#                 max=2,
#                 step=0.1,
#             ),
#             Slider(
#                 id="SAI_Steps",
#                 label="Stability AI - Steps",
#                 initial=30,
#                 min=10,
#                 max=150,
#                 step=1,
#                 description="Amount of inference steps performed on image generation.",
#             ),
#             Slider(
#                 id="SAI_Cfg_Scale",
#                 label="Stability AI - Cfg_Scale",
#                 initial=7,
#                 min=1,
#                 max=35,
#                 step=0.1,
#                 description="Influences how strongly your generation is guided to match your prompt.",
#             ),
#             Slider(
#                 id="SAI_Width",
#                 label="Stability AI - Image Width",
#                 initial=512,
#                 min=256,
#                 max=2048,
#                 step=64,
#                 tooltip="Measured in pixels",
#             ),
#             Slider(
#                 id="SAI_Height",
#                 label="Stability AI - Image Height",
#                 initial=512,
#                 min=256,
#                 max=2048,
#                 step=64,
#                 tooltip="Measured in pixels",
#             ),
#         ]
#     ).send()


@cl.on_settings_update
async def setup_agent(settings):
    print("on_settings_update", settings)


# Session Management
def get_user_sessions(username: str) -> List[str]:
    if not redis_client:
        return []
    return redis_client.smembers(f"sessions:{username}") or []

# # Chainlit Handlers
@cl.on_chat_start
async def start_chat():
  
    user = cl.user_session.get("user")
    if not user:
        await cl.Message(content="Authentication required").send()
        return
    
    # Generate session ID and JWT
    session_id = cl.user_session.get("id") or str(time.time_ns())
    cl.user_session.set("id", session_id)
    token = create_jwt(user.identifier)
    cl.user_session.set("token", token)
    
    # Show resume options
    sessions = get_user_sessions(user.identifier)
    if sessions:
        actions = [
            cl.Action(
                name=f"resume_{sid}",
                payload={"session_id": sid},  # Add a valid payload
                label=f"Session {sid[-6:]}"
            ) for sid in sessions if sid != session_id
        ]
        # await cl.Message(content="Active sessions:", actions=actions).send()

# async def start():
#         with cl.Sidebar():
#             cl.Markdown("settings")
#             theme = cl.Select(
#                 options=["Light", "Dark"],
#                 value="Light",
#                 label="Choose Theme",
#             )
#             toggle = cl.Switch(value=False,
#                                label="Enable Feature!")
            
#             if toggle:
#                 cl.Text("Feature enabled!")




# @cl.on_chat_start
# async def start():
#     files = None

#     # Wait for the user to upload a file
#     while files == None:
#         files = await cl.AskFileMessage(
#             content="Please upload a text file to begin!", accept=["text/plain"]
#         ).send()

#     text_file = files[0]

#     with open(text_file.path, "r", encoding="utf-8") as f:
#         text = f.read()

#     # Let the user know that the system is ready
#     await cl.Message(
#         content=f"`{text_file.name}` uploaded, it contains {len(text)} characters!"
#     ).send()
# message
@cl.on_message
async def on_message(message: cl.Message):
    user =cl.user_session.get("user")
    token =cl.user_session.get("token")
    username=user.identifier
    session_id = cl.user_session.get("id")
    if not session_id:
        await cl.Message(content="Error: Session ID is missing!").send()
        return
    new_message = {"role": "user", "content": message.content}

    if not user or not validate_jwt(token):
        await cl.Message(content="Session expired. please refresh").send()

    # Regular chat message processing
    chat_history = get_chat_history(username,session_id)
    formatted_history = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history] if chat_history else []
    
    # Append the user's current message to the history
    formatted_history.append({"role": "user", "content": message.content})

    # Save the user's message to Redis chat history
    save_chat_history(username, session_id, "user", message.content)

    # Get the assistant's response from LLaMA API based on the conversation history
    # response = llama_completion(new_message, formatted_history)
    response = llama_completion(formatted_history)
    
    
    # Save the assistant's response to Redis chat history
    save_chat_history(username, session_id, "assistant", response)
    
    # # format responce for reply like {'role': 'assistant', 'content': 'Hello! How can I assist you today?'}
    # if response[:2]=="{'":
    #     response=response[34:-2]

    # Prepare message to stream token responses
    msg = cl.Message(content="")
    await msg.send()
    try:
        # Stream the response tokens in real-time
        for token in response:
            await msg.stream_token(token)
        # Optionally, send a message that the streaming is complete
        # await cl.Message(content="All tokens streamed successfully.").send()
    except Exception as e:
        await cl.Message(content=f"Error streaming response: {e}").send()

    # Retrieve the updated chat history from Redis (with the most recent messages)
    updated_history = get_chat_history(username ,session_id)

    # Display the last 10 messages for performance
    history_elements = [
        cl.Text(content=f" {msg['role'].capitalize()}: {msg['content']}", name=f"message_{index}")
        for index, msg in enumerate(updated_history)  # Only show the last 10 messages
    ]
   
        
    # Optionally, display a brief "History updated!" message in the sidebar
    await cl.ElementSidebar.set_elements([cl.Text(content="History updated!")])
    await cl.ElementSidebar.set_title("Chat History")
    # await cl.sleep(2)  # Briefly display the "History updated!" message
    await cl.ElementSidebar.set_elements(history_elements)  # Ensure history stays in sidebar
    # print(history_elements,"111111111111111111111")

    # Store session ID in Redis to track active chat sessions (optional)
    if redis_client:
        redis_client.sadd("chat_sessions", session_id)


@cl.on_chat_resume
async def on_chat_resume(thread):
    pass

@cl.action_callback(name="resume_")
async def resume_session(action: cl.Action):
    user = cl.user_session.get("user")
    new_session_id = action.value
    
    # Verify session ownership
    if new_session_id in get_user_sessions(user.identifier):
        # Close current session
        cl.user_session.set("id", new_session_id)
        await cl.Message(content=f"Resumed session {new_session_id[-6:]}").send()
        
        # Load history for new session
        history = get_chat_history(user.identifier, new_session_id)
        for msg in history:
            await cl.Message(content=msg['content']).send()
    else:
        await cl.Message(content="Session not found").send()









