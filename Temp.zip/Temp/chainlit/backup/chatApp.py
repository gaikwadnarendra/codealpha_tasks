import chainlit as cl
import redis
import json
import requests
from dotenv import load_dotenv
import os
from typing import Optional, List, Dict
import time
import jwt
from jwt.exceptions import InvalidTokenError
from chainlit.types import ThreadDict
from langchain.memory import ConversationBufferMemory
from chainlit.input_widget import Select, Switch, Slider

# Load environment variables
load_dotenv()
JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET", "default_secret")
JWT_ALGORITHM = "HS256"
SESSION_EXPIRY = 3600  # 1 hour

# User database (replace with proper database in production)
user_db = {
    "admin": {"password": "admin", "role": "admin"},
    "user1": {"password": "user1pass", "role": "user"},
}

# Redis setup
redis_client = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)

# Chat service endpoint
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"
# CHAT_SERVICE_URL = "ws://192.168.0.243:9090/v1/chat/completions/ws"

# JWT Utilities
def create_jwt(username: str) -> str:
    return jwt.encode(
        {
            "username": username,
            "exp": time.time() + SESSION_EXPIRY
        },
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

def validate_jwt(token: str) -> bool:
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return True
    except InvalidTokenError:
        return False


# Authentication ##########################################################
@cl.password_auth_callback
async def auth_callback(username: str, password: str) -> Optional[cl.User]:
    if user_db.get(username) and user_db[username]["password"] == password:
        return cl.User(
            identifier=username,
            metadata={"role": user_db[username]["role"]}
        )
    return None

@cl.oauth_callback
def oauth_callback(
    provider_id: str,
    token: str,
    raw_user_data: Dict[str, str],
    default_user: cl.User,
) -> Optional[cl.User]:
    return default_user  # Allow all users to authenticate

######################################################################################

# Function to get responses from LLaMA API ##############################################################
def llama_completion(messages):
    try:
        data = {"messages": messages}
        headers = {"Content-Type": "application/json"}
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Ensure we raise an error for HTTP issues
        response_json = response.json()
        return response_json['choices'][0]['message']['content']
    except requests.RequestException as e:
        print(f"Error communicating with LLaMA API: {e}")
        return "Service Unavailable"

#############################################################################################################

# Function to persist user settings (e.g., theme, preferences)
def save_user_settings(username: str, settings: Dict):
    if not redis_client:
        return
    try:
        redis_client.set(f"user_settings:{username}", json.dumps(settings))
        redis_client.expire(f"user_settings:{username}", 86400)  # Expire in 24 hours
    except redis.RedisError as e:
        print(f"Error saving user settings: {e}")

def get_user_settings(username: str) -> Dict:
    if not redis_client:
        return {}
    try:
        settings = redis_client.get(f"user_settings:{username}")
        return json.loads(settings) if settings else {}
    except redis.RedisError as e:
        print(f"Error fetching user settings: {e}")
        return {}

# Function to save chat history (as you've already done)
def save_chat_history(username: str, session_id: str, role: str, content: str):
    if not redis_client:
        return
    
    try:
        key = f"chat:{username}:{session_id}"
        redis_client.rpush(key, json.dumps({
            "role": role,
            "content": content,
            "timestamp": time.time()
        }))
        redis_client.expire(key, 86400)  # Expire after 24 hours
    except redis.RedisError as e:
        print(f"Redis error: {e}")

def get_chat_history(username: str, session_id: str) -> List[Dict]:
    if not redis_client:
        return []
    
    try:
        key = f"chat:{username}:{session_id}"
        return [json.loads(msg) for msg in redis_client.lrange(key, 0, -1)]
    except redis.RedisError as e:
        print(f"Redis error: {e}")
        return []

# Function to persist session IDs for tracking active sessions
def save_user_sessions(username: str, session_id: str):
    if not redis_client:
        return
    try:
        redis_client.sadd(f"sessions:{username}", session_id)
        redis_client.expire(f"sessions:{username}", 86400)  # Expire in 24 hours
    except redis.RedisError as e:
        print(f"Redis error: {e}")

def get_user_sessions(username: str) -> List[str]:
    if not redis_client:
        return []
    try:
        return list(redis_client.smembers(f"sessions:{username}"))
    except redis.RedisError as e:
        print(f"Redis error: {e}")
        return []

# Chainlit Handlers
@cl.on_chat_start
async def start():
    user = cl.user_session.get("user")
    if not user:
        await cl.Message(content="Authentication required").send()
        return
    
    # Generate session ID and JWT
    session_id = cl.user_session.get("id") or str(time.time_ns())
    cl.user_session.set("id", session_id)
    token = create_jwt(user.identifier)
    cl.user_session.set("token", token)
    
    # Save session information in Redis
    save_user_sessions(user.identifier, session_id)
    
    # Show resume options if there are any active sessions
    sessions = get_user_sessions(user.identifier)
    if sessions:
        actions = [
            cl.Action(
                name=f"resume_{sid}",
                payload={"session_id": sid},  # Add a valid payload
                label=f"Session {sid[-6:]}"
            ) for sid in sessions if sid != session_id
        ]
        # await cl.Message(content="Active sessions:", actions=actions).send()

@cl.on_message
async def on_message(message: cl.Message):
    user = cl.user_session.get("user")
    token = cl.user_session.get("token")
    username = user.identifier

    if not user or not validate_jwt(token):
        await cl.Message(content="Session expired. please refresh").send()
        return

    session_id = cl.user_session.get("id")
    if not session_id:
        await cl.Message(content="Error: Session ID is missing!").send()
        return

    # Handle the 'show_history' action when the user clicks the button in the sidebar
    if message.metadata.get("action") == "show_history":
        chat_history = get_chat_history(username, session_id)
        
        # Format the history as text to display
        history_content = "User History:\n"
        for msg in chat_history:
            if msg['content'][:2] == "{'":
                history_content += f"{msg['role'].capitalize()}: {msg['content'][34:-2]}\n"
            else:
                history_content += f"{msg['role'].capitalize()}: {msg['content']}\n"
        
        await cl.Message(content=history_content).send()
        await cl.ElementSidebar.set_elements([cl.Text(content="History updated!")])

    else:
        # Regular chat message processing
        chat_history = get_chat_history(username, session_id)
        formatted_history = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history] if chat_history else []
        
        # Append the user's current message to the history
        formatted_history.append({"role": "user", "content": message.content})

        # Save the user's message to Redis chat history
        save_chat_history(username, session_id, "user", message.content)

        # Get the assistant's response from LLaMA API based on the conversation history
        response = llama_completion(formatted_history)
        
        # Save the assistant's response to Redis chat history
        save_chat_history(username, session_id, "assistant", response)

        # Prepare message to stream token responses
        msg = cl.Message(content="")
        await msg.send()

        try:
            # Stream the response tokens in real-time
            for token in response:
                await msg.stream_token(token)
        except Exception as e:
            await cl.Message(content=f"Error streaming response: {e}").send()

        # Retrieve the updated chat history from Redis (with the most recent messages)
        updated_history = get_chat_history(username, session_id)
        history_elements = [
            cl.Text(content=f"{msg['role'].capitalize()}: {msg['content']}", name=f"message_{index}")
            for index, msg in enumerate(updated_history)
        ]
        await cl.ElementSidebar.set_elements(history_elements)
        await cl.ElementSidebar.set_title("Chat History")

        # Store session ID in Redis to track active chat sessions (optional)
        if redis_client:
            redis_client.sadd("chat_sessions", session_id)

# Resume the session
@cl.action_callback(name="resume_")
async def resume_session(action: cl.Action):
    user = cl.user_session.get("user")
    new_session_id = action.value
    
    if new_session_id in get_user_sessions(user.identifier):
        cl.user_session.set("id", new_session_id)
        await cl.Message(content=f"Resumed session {new_session_id[-6:]}").send()
        
        history = get_chat_history(user.identifier, new_session_id)
        for msg in history:
            await cl.Message(content=msg['content']).send()
    else:
        await cl.Message(content="Session not found").send()
