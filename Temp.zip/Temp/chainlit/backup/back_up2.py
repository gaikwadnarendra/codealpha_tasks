import chainlit as cl
import redis
import json
import requests
from dotenv import load_dotenv
import os
from typing import Optional, List,Dict
import time
import jwt
from jwt.exceptions import InvalidTokenError
from chainlit.types import ThreadDict
from langchain.memory import ConversationBufferMemory
# Load environment variables
load_dotenv()
JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET", "default_secret")
JWT_ALGORITHM = "HS256"
SESSION_EXPIRY = 3600  # 1 hour

# User database (replace with proper database in production)
user_db = {
    "admin": {"password": "admin", "role": "admin"},
    "user1": {"password": "user1pass", "role": "user"},
}


# Redis setup
redis_client = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)

# Chat service endpoint
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"
# CHAT_SERVICE_URL = "ws://192.168.0.243:9090/v1/chat/completions/ws"


# JWT Utilities
def create_jwt(username: str) -> str:
    return jwt.encode(
        {
            "username": username,
            "exp": time.time() + SESSION_EXPIRY
        },
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

def validate_jwt(token: str) -> bool:
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return True
    except InvalidTokenError:
        return False



# Authentication
@cl.password_auth_callback
async def auth_callback(username: str, password: str) -> Optional[cl.User]:
    if user_db.get(username) and user_db[username]["password"] == password:
        return cl.User(
            identifier=username,
            metadata={"role": user_db[username]["role"]}
        )
    return None


# Function to get responses from LLaMA API
def llama_completion(messages):
    try:
        data = {"messages": messages}
        headers = {"Content-Type": "application/json"}
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Ensure we raise an error for HTTP issues
        response_json = response.json()
        return response_json['choices'][0]['message']['content']
    except requests.RequestException as e:
        print(f"Error communicating with LLaMA API: {e}")
        return "Service Unavailable"


@cl.set_starters
async def set_starters():
    samples = []
    with open(os.path.join('public', 'sample.json'), 'r') as f:
        samples = json.loads(f.read())
    
    starter_prompts = []
    for sam in samples:
        starter_prompts.append(
                cl.Starter(
                label=sam['label'],
                message=sam['message'],
                icon=sam['icon'],
            ))
    
    return starter_prompts



# Chat History Management
def save_chat_history(username: str, session_id: str, role: str, content: str):
    if not redis_client:
        return
    
    try:
        key = f"chat:{username}:{session_id}"
        redis_client.rpush(key, json.dumps({
            "role": role,
            "content": content,
            "timestamp": time.time()
        }))
        redis_client.expire(key, 86400)  # Expire after 24h
        
        # Track user sessions
        # redis_client.sadd(f"sessions:{username}", session_id)
    except redis.RedisError as e:
        print(f"Redis error: {e}")

def get_chat_history(username: str, session_id: str) -> List[Dict]:
    if not redis_client:
        return []
    
    try:
        key = f"chat:{username}:{session_id}"
        return [json.loads(msg) for msg in redis_client.lrange(key, 0, -1)]
    except redis.RedisError as e:
        print(f"Redis error: {e}")
        return []





# Session Management
def get_user_sessions(username: str) -> List[str]:
    if not redis_client:
        return []
    return redis_client.smembers(f"sessions:{username}") or []

# # Chainlit Handlers
@cl.on_chat_start
async def start_chat():
  
    user = cl.user_session.get("user")
    if not user:
        await cl.Message(content="Authentication required").send()
        return
    
    # Generate session ID and JWT
    session_id = cl.user_session.get("id") or str(time.time_ns())
    cl.user_session.set("id", session_id)
    token = create_jwt(user.identifier)
    cl.user_session.set("token", token)
    
    # Show resume options
    sessions = get_user_sessions(user.identifier)
    if sessions:
        actions = [
            cl.Action(
                name=f"resume_{sid}",
                payload={"session_id": sid},  # Add a valid payload
                label=f"Session {sid[-6:]}"
            ) for sid in sessions if sid != session_id
        ]
        # await cl.Message(content="Active sessions:", actions=actions).send()

async def start():
        with cl.Sidebar():
            cl.Markdown("settings")
            theme = cl.Select(
                options=["Light", "Dark"],
                value="Light",
                label="Choose Theme",
            )
            toggle = cl.Switch(value=False,
                               label="Enable Feature!")
            
            if toggle:
                cl.Text("Feature enabled!")

# message
@cl.on_message
async def on_message(message: cl.Message):
    user =cl.user_session.get("user")
    token =cl.user_session.get("token")
    username=user.identifier

    new_message = {"role": "user", "content": message.content}

    if not user or not validate_jwt(token):
        await cl.Message(content="Session expired. please refresh").send()

    session_id = cl.user_session.get("id")
    if not session_id:
        await cl.Message(content="Error: Session ID is missing!").send()
        return

    # Handle the 'show_history' action when the user clicks the button in the sidebar
    if message.metadata.get("action") == "show_history":
        # Fetch the user history from Redis or any other storage method
        chat_history = get_chat_history(username,session_id)
        
        # Format the history as text to display
        history_content = "User History:\n"
        for msg in chat_history:
            # format responce for reply like {'role': 'assistant', 'content': 'Hello! How can I assist you today?'}
            if msg['content'][:2]=="{'":     
                history_content += f"{msg['role'].capitalize()}: {msg['content'][34:-2]}\n"
            else:
                history_content += f"{msg['role'].capitalize()}: {msg['content']}\n"
        
        # Send the user history as a message
        await cl.Message(content=history_content).send()

        # Optionally, update the sidebar elements to show a message or button again
        elements = [
            cl.Text(content="Click to View User History", name="history_button", metadata={"action": "show_history"})
        ]
        await cl.ElementSidebar.set_elements(elements)
        await cl.ElementSidebar.set_title("Sidebar Menu")

    else:
        # Regular chat message processing
        chat_history = get_chat_history(username,session_id)
        formatted_history = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history] if chat_history else []
        
        # Append the user's current message to the history
        formatted_history.append({"role": "user", "content": message.content})

        # Save the user's message to Redis chat history
        save_chat_history(username, session_id, "user", message.content)

        # Get the assistant's response from LLaMA API based on the conversation history
        # response = llama_completion(new_message, formatted_history)
        response = llama_completion(formatted_history)
        
     
        # Save the assistant's response to Redis chat history
        save_chat_history(username, session_id, "assistant", response)
        
        # format responce for reply like {'role': 'assistant', 'content': 'Hello! How can I assist you today?'}
        if response[:2]=="{'":
            response=response[34:-2]

        # Prepare message to stream token responses
        msg = cl.Message(content="")
        await msg.send()

        try:
            # Stream the response tokens in real-time
            for token in response:
                await msg.stream_token(token)
            # Optionally, send a message that the streaming is complete
            # await cl.Message(content="All tokens streamed successfully.").send()
        except Exception as e:
            await cl.Message(content=f"Error streaming response: {e}").send()

        # Retrieve the updated chat history from Redis (with the most recent messages)
        updated_history = get_chat_history(username ,session_id)

        # Display the last 10 messages for performance
        history_elements = [
            cl.Text(content=f"{msg['role'].capitalize()}: {msg['content']}", name=f"message_{index}")
            for index, msg in enumerate(updated_history)  # Only show the last 10 messages
        ]
        # Set the sidebar elements to display the latest chat history
        await cl.ElementSidebar.set_elements(history_elements)
        await cl.ElementSidebar.set_title("Chat History")

        # Optionally, display a brief "History updated!" message in the sidebar
        await cl.ElementSidebar.set_elements([cl.Text(content="History updated!")])
        await cl.ElementSidebar.set_title("Chat History")
        await cl.sleep(2)  # Briefly display the "History updated!" message
        await cl.ElementSidebar.set_elements(history_elements)  # Ensure history stays in sidebar

        # Store session ID in Redis to track active chat sessions (optional)
        if redis_client:
            redis_client.sadd("chat_sessions", session_id)


@cl.on_chat_resume
async def on_chat_resume(thread):
    pass

@cl.action_callback(name="resume_")
async def resume_session(action: cl.Action):
    user = cl.user_session.get("user")
    new_session_id = action.value
    
    # Verify session ownership
    if new_session_id in get_user_sessions(user.identifier):
        # Close current session
        cl.user_session.set("id", new_session_id)
        await cl.Message(content=f"Resumed session {new_session_id[-6:]}").send()
        
        # Load history for new session
        history = get_chat_history(user.identifier, new_session_id)
        for msg in history:
            await cl.Message(content=msg['content']).send()
    else:
        await cl.Message(content="Session not found").send()


# @cl.action_callback(name="resume_")
# async def resume_session(action: cl.Action):
#     user = cl.user_session.get("user")
#     new_session_id = action.payload.get("session_id")  # Use payload to get session_id
    
#     # Verify session ownership
#     if new_session_id in get_user_sessions(user.identifier):
#         # Close current session
#         cl.user_session.set("id", new_session_id)
#         await cl.Message(content=f"Resumed session {new_session_id[-6:]}").send()
        
#         # Load history for new session
#         history = get_chat_history(user.identifier, new_session_id)
#         for msg in history:
#             await cl.Message(content=msg['content']).send()
#     else:
#         await cl.Message(content="Session not found").send()








