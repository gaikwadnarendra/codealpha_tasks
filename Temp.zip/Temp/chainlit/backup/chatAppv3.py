from typing import Optional, Dict, List
import chainlit as cl
from dotenv import load_dotenv
import os
import redis
import requests
import json
import time
import jwt
from chainlit.input_widget import Select, Switch, Slider

# Load environment variables from .env file
load_dotenv()

# Define chat service URL
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"

# JWT Configuration
JWT_SECRET = os.getenv("CHAINLIT_AUTH_SECRET")
JWT_ALGORITHM = "HS256"

if not JWT_SECRET:
    raise ValueError("JWT_SECRET is not set in the environment variables.")

# User database (for demo purposes)
user_db = {
    "admin": {"password": "admin", "role": "admin"},
    "user1": {"password": "pass", "role": "user"},
}

# New user registration
new_users = {}

# Connect to Redis
try:
    redis_client = redis.StrictRedis(host="localhost", port=6379, db=0, decode_responses=True)
    redis_client.ping()
    print("Connected to Redis successfully.")
except redis.ConnectionError:
    print("Error: Unable to connect to Redis.")
    redis_client = None

# Function to get responses from LLaMA API
def llama_completion(messages):
    try:
        data = {"messages": messages}
        headers = {"Content-Type": "application/json"}
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()
        response_json = response.json()
        return response_json['choices'][0]['message']['content']
    except requests.RequestException as e:
        print(f"Error communicating with LLaMA API: {e}")
        return "Service Unavailable"

# Function to generate a JWT token
def generate_token(username):
    payload = {'username': username, 'exp': int(time.time()) + 3600}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

# Validate JWT function
def validate_jwt(token):
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return True
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False

# Implementing password authentication callback
@cl.password_auth_callback
async def auth_callback(username: str, password: str) -> Optional[cl.User]:
    if username in user_db and user_db[username]["password"] == password:
        token = generate_token(username)
        return cl.User(
            identifier=username,
            metadata={"role": user_db[username]["role"], "provider": "credentials", "token": token},
        )
    elif username in new_users and new_users[username]["password"] == password:
        token = generate_token(username)
        return cl.User(
            identifier=username,
            metadata={"role": new_users[username]["role"], "provider": "credentials", "token": token},
        )
    else:
        return None


# Chat History Management
def save_chat_history(username: str, session_id: str, role: str, content: str):
    if not redis_client:
        return
    
    try:
        key = f"chat:{username}:{session_id}"
        redis_client.rpush(key, json.dumps({
            "role": role,
            "content": content,
            "timestamp": time.time()
        }))
        redis_client.expire(key, 86400)  # Expire after 24h
        
        # Track user sessions
        # redis_client.sadd(f"sessions:{username}", session_id)
    except redis.RedisError as e:
        print(f"Redis error: {e}")

def get_chat_history(username: str, session_id: str) -> List[Dict]:
    if not redis_client:
        return []
    
    try:
        key = f"chat:{username}:{session_id}"
        return [json.loads(msg) for msg in redis_client.lrange(key, 0, -1)]
    except redis.RedisError as e:
        print(f"Redis error: {e}")
        return []

# Implementing a signup function
@cl.on_message
async def on_message(message: cl.Message):
    if message.content.startswith("/signup"):
        parts = message.content.split(" ")
        if len(parts) != 3:
            await cl.Message(content="Usage: /signup <username> <password>").send()
            return

        username = parts[1]
        password = parts[2]

        if username in user_db or username in new_users:
            await cl.Message(content="Username already exists.").send()
            return

        new_users[username] = {"password": password, "role": "user"}
        await cl.Message(content=f"User {username} successfully registered. Please log in.").send()
    else:
        # Handle regular chat messages
        await process_chat_message(message)

# Function to handle regular chat messages
async def process_chat_message(message: cl.Message):
    user = cl.user_session.get("user")
    if not user:
        await cl.Message(content="Please log in or sign up to continue.").send()
        return

    # Your existing code for handling chat messages goes here
    # ...

    session_id = cl.user_session.get("id")
    if not session_id:
        session_id = str(int(time.time()))
        cl.user_session.set("id", session_id)
    # Authentication and session handling

# Chainlit event handlers
@cl.on_chat_start
async def on_chat_start():
    # Authentication and session handling
    user = cl.user_session.get("user")
    if not user:
        await cl.Message(content="Please log in or sign up to continue. You can sign up using the command /signup <username> <password>.").send()
        return

    session_id = cl.user_session.get("id")
    if not session_id:
        session_id = str(int(time.time()))
        cl.user_session.set("id", session_id)

    # Retrieve and send chat history
    chat_history = get_chat_history(session_id)
    if not chat_history:
        await cl.Message(content="Welcome! How can I assist you today?").send()

    # Send initial response or system message to LLaMA
    system_message = "You are a helpful assistant."
    messages = [{"role": "system", "content": system_message}]
    response_content = llama_completion(messages)

    msg = cl.Message(content="")
    await msg.send()
    for token in response_content:
        await msg.stream_token(token)

    # Settings UI (Select Model, Temperature, etc.)
    settings = await cl.ChatSettings(
        [
            Select(id="Model", label="OpenAI - Model", values=["gpt-3.5-turbo", "gpt-4"], initial_index=0),
            Switch(id="Streaming", label="OpenAI - Stream Tokens", initial=True),
            Slider(id="Temperature", label="OpenAI - Temperature", initial=1, min=0, max=2, step=0.1),
        ]
    ).send()

    elements = [
        cl.Text(content="Click to View User History", name="history_button", metadata={"action": "show_history"})
    ]
    # Set sidebar elements and title
    await cl.ElementSidebar.set_elements(elements)
    await cl.ElementSidebar.set_title("Sidebar Menu")

@cl.on_settings_update
async def setup_agent(settings: Dict):
    print("on_settings_update", settings)
# Profile versions
@cl.set_chat_profiles
async def chat_profile():
    return [
        cl.ChatProfile(
            name="GPT-3.5",
            markdown_description="The Chainlit model **GPT-3.5**.",
            icon="https://mintlify.s3-us-west-1.amazonaws.com/chainlit-43/_generated/favicon/apple-touch-icon.png?v=3",
        ),
        cl.ChatProfile(
            name="GPT-4",
            markdown_description="The Chainlit model **GPT-4**.",
            icon="https://pbs.twimg.com/profile_images/1657041791613370369/sm9jmDm3_400x400.jpg",
        ),
         cl.ChatProfile(
            name="GPT-5",
            markdown_description="The Chainlit model **GPT-5**.",
            icon="https://pbs.twimg.com/profile_images/1657041791613370369/sm9jmDm3_400x400.jpg",
        ),
    ]

@cl.on_message
async def on_message(message: cl.Message):
    # Check if the user is trying to sign up
    if message.content.startswith("/signup"):
        # Extract username and password from the message
        parts = message.content.split(" ")
        if len(parts) != 3:
            await cl.Message(content="Usage: /signup <username> <password>").send()
            return
        username = parts[1]
        password = parts[2]
        # Validate the username
        if not username.isalnum() or len(username) < 3:
            await cl.Message(
                content="Username must be alphanumeric and at least 3 characters long."
            ).send()
            return
        # Validate the password
        if len(password) < 8:
            await cl.Message(content="Password must be at least 8 characters long.").send()
            return
        # Check if the username already exists in the user_db or new_users
        if username in user_db or username in new_users:
            await cl.Message(content="Username already exists.").send()
            return
        # Register the new user in the new_users dictionary
        new_users[username] = {"password": password, "role": "user"}
        # Send a success message to the user
        await cl.Message(content=f"User {username} successfully registered. Please log in.").send()
    else:
        session_id = cl.user_session.get("id")
        if not session_id:
            await cl.Message(content="Error: Session ID is missing!").send()
            return

        # Handle the 'show_history' action when the user clicks the button in the sidebar
        if message.metadata and message.metadata.get("action") == "show_history":
            # Fetch the user history from Redis or any other storage method
            chat_history = get_chat_history(session_id)
            # Format the history as text to display
            history_content = "User History:\n"
            for msg in chat_history:
                history_content += f"{msg['role'].capitalize()}: {msg['content']}\n"
            # Send the user history as a message
            await cl.Message(content=history_content).send()

            # Optionally, update the sidebar elements to show a message or button again
            elements = [
                cl.Text(content="Click to View User History", name="history_button", metadata={"action": "show_history"})
            ]
            await cl.ElementSidebar.set_elements(elements)
            await cl.ElementSidebar.set_title("Sidebar Menu")
        else:
            # Regular chat message processing
            chat_history = get_chat_history(session_id)
            formatted_history = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history] if chat_history else []
            # Append the user's current message to the history
            formatted_history.append({"role": "user", "content": message.content})
            # Save the user's message to Redis chat history
            save_chat_history(session_id, "user", message.content)

            # Get the assistant's response from LLaMA API based on the conversation history
            response = llama_completion(formatted_history)

            # Save the assistant's response to Redis chat history
            save_chat_history(session_id, "assistant", response)

            # Prepare message to stream token responses
            msg = cl.Message(content="")
            await msg.send()
            try:
                # Stream the response tokens in real-time
                for token in response:
                    await msg.stream_token(token)
            except Exception as e:
                await cl.Message(content=f"Error streaming response: {e}").send()

            # Retrieve the updated chat history from Redis (with the most recent messages)
            updated_history = get_chat_history(session_id)
            # Display the last 10 messages for performance
            history_elements = [
                cl.Text(content=f"{msg['role'].capitalize()}: {msg['content']}", name=f"message_{index}")
                for index, msg in enumerate(updated_history[-10:])  # Only show the last 10 messages
            ]

            # Set the sidebar elements to display the latest chat history
            await cl.ElementSidebar.set_elements(history_elements)
            await cl.ElementSidebar.set_title("Chat History")
            # Optionally, display a brief "History updated!" message in the sidebar
            await cl.ElementSidebar.set_elements([cl.Text(content="History updated!")])
            await cl.ElementSidebar.set_title("Chat History")
            await cl.sleep(2) # Briefly display the "History updated!" message
            await cl.ElementSidebar.set_elements(history_elements) # Ensure history stays in sidebar
            # Store session ID in Redis to track active chat sessions (optional)
            if redis_client:
                redis_client.sadd("chat_sessions", session_id)

