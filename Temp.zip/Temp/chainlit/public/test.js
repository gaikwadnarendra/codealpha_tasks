document.querySelectorAll('a span').forEach(function(link) {
    link.href = "https://www.credentek.com";
});
console.log("Watermark element not found!");
// Check for a stored flag to determine if custom text should be displayed
let customTextFlag = localStorage.getItem('showCustomText') === 'true';

// Initially add/remove the custom-text class based on stored state
if (customTextFlag) {
    document.querySelector('.watermark span').classList.add('custom-text');
} else {
    document.querySelector('.watermark span').classList.remove('custom-text');
}

// Function to toggle the custom text state when clicked
document.querySelector('.watermark').addEventListener('click', function() {
    const spanElement = document.querySelector('.watermark span');
    const currentState = localStorage.getItem('showCustomText');

    // Toggle state: If currently showing custom text, remove it, else show it
    if (currentState === 'true') {
        localStorage.setItem('showCustomText', 'false');
        spanElement.classList.remove('custom-text');
    } else {
        localStorage.setItem('showCustomText', 'true');
        spanElement.classList.add('custom-text');
    }
});

document.addEventListener("DOMContentLoaded", function() {
    let watermarkText = document.querySelector(".watermark span");
    if (watermarkText) {
        watermarkText.innerHTML = "© 2025 Credentek Pvt. Ltd. All rights reserved.";
    }
});
