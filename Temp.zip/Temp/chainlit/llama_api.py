import json
import requests

# Chat service endpoint
CHAT_SERVICE_URL = "http://192.168.0.243:9090/v1/chat/completions"

# Function to get responses from LLaMA API 
def llama_completion(messages):
    try:
        data = {"messages": messages}
        headers = {"Content-Type": "application/json"}
        response = requests.post(CHAT_SERVICE_URL, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Ensure we raise an error for HTTP issues
        response_json = response.json()
        return response_json['choices'][0]['message']['content']
    except requests.RequestException as e:
        print(f"Error communicating with LLaMA API: {e}")
        return "Service Unavailable"

