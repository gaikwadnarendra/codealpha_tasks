from fastapi import FastAPI
from chainlit.utils import mount_chainlit
import uvicorn
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from starlette.requests import Request

app = FastAPI()

mount_chainlit(app=app, target="chatbot.py", path="/chainlit")
# Setup templates directory for rendering HTML
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

if __name__ == "__main__":
    uvicorn.run(app, port=8000, reload=True)